import { useState, useEffect, createContext, useContext } from 'react'
import { supabase } from './supabaseClient'
import type { User, Session } from '@supabase/supabase-js'

// ─── Types ───────────────────────────────────────────────────────
type Plan = 'free' | 'pro' | 'team'

interface UserProfile {
  id: string
  email: string
  name: string
  plan: Plan
  project_count: number
  created_at: string
}

interface AuthContextType {
  user: User | null
  profile: UserProfile | null
  session: Session | null
  plan: Plan
  canCreateProject: boolean
  canExportPDF: boolean
  projectCount: number
  loading: boolean
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

// ─── Theme ───────────────────────────────────────────────────────
const T = {
  navy:   '#1B4F8A',
  blue:   '#2563EB',
  light:  '#EEF4FB',
  bg:     '#F4F7FB',
  white:  '#FFFFFF',
  border: '#DDE6F0',
  text:   '#1A2B3C',
  muted:  '#5A7A9A',
  green:  '#15803D',
  greenBg:'#E6F4EC',
  amber:  '#92520A',
  red:    '#991B1B',
  mid:    '#3B82F6',
}

// ─── Context ─────────────────────────────────────────────────────
const AuthContext = createContext<AuthContextType | null>(null)
export const useAuth = () => useContext(AuthContext)!

const FREE_PROJECT_LIMIT = 3

// ─── Auth Provider ───────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser]       = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()
    if (data) setProfile(data)
  }

  const refreshProfile = async () => {
    if (user) await fetchProfile(user.id)
  }

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) await fetchProfile(session.user.id)
      setLoading(false)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      if (session?.user) await fetchProfile(session.user.id)
      else setProfile(null)
    })

    return () => subscription.unsubscribe()
  }, [])

  const plan: Plan = profile?.plan ?? 'free'
  const projectCount = profile?.project_count ?? 0
  const canCreateProject = plan !== 'free' || projectCount < FREE_PROJECT_LIMIT
  const canExportPDF = plan !== 'free'

  const signOut = async () => {
    await supabase.auth.signOut()
    setUser(null); setSession(null); setProfile(null)
  }

  return (
    <AuthContext.Provider value={{ user, profile, session, plan, canCreateProject, canExportPDF, projectCount, loading, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

// ─── Login Page ──────────────────────────────────────────────────
function LoginPage() {
  const [mode, setMode]       = useState<'login' | 'signup'>('login')
  const [email, setEmail]     = useState('')
  const [password, setPassword] = useState('')
  const [name, setName]       = useState('')
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent]       = useState(false)

  const inputS: React.CSSProperties = {
    width: '100%', padding: '10px 13px', border: `1.5px solid ${T.border}`,
    borderRadius: 7, fontSize: 14, fontFamily: 'inherit', outline: 'none',
    background: T.white, color: T.text, marginTop: 4,
  }

  const handleEmail = async () => {
    setError(''); setLoading(true)
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { name }, emailRedirectTo: window.location.origin }
        })
        if (error) throw error
        setSent(true)
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
      }
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const handleGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin }
    })
  }

  if (sent) return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: T.white, borderRadius: 14, border: `1px solid ${T.border}`, padding: '40px 36px', maxWidth: 400, width: '100%', textAlign: 'center' }}>
        <div style={{ fontSize: 32, marginBottom: 16 }}>✉️</div>
        <div style={{ fontSize: 18, fontWeight: 700, color: T.navy, marginBottom: 8 }}>Check your email</div>
        <div style={{ fontSize: 14, color: T.muted, lineHeight: 1.6 }}>
          We sent a confirmation link to <strong>{email}</strong>. Click it to activate your account.
        </div>
      </div>
    </div>
  )

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ background: T.white, borderBottom: `1px solid ${T.border}`, padding: '0 24px', height: 52, display: 'flex', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 28, height: 28, background: T.navy, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ color: '#fff', fontSize: 13, fontWeight: 800 }}>B·</span>
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: T.navy }}>BESSAnalytica</div>
            <div style={{ fontSize: 9, color: T.muted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>BESS Project Costing & Financial Analysis · India</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ width: '100%', maxWidth: 440 }}>

          {/* Hero text */}
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ fontSize: 26, fontWeight: 800, color: T.navy, letterSpacing: '-0.02em', marginBottom: 8 }}>
              India's BESS financial analysis platform
            </div>
            <div style={{ fontSize: 14, color: T.muted, lineHeight: 1.6 }}>
              LCOS · DCF · IRR · Bankability · Bid Optimiser — built for Indian market realities.
            </div>
          </div>

          {/* Card */}
          <div style={{ background: T.white, borderRadius: 14, border: `1px solid ${T.border}`, padding: '32px 28px' }}>

            {/* Mode toggle */}
            <div style={{ display: 'flex', background: '#F0F4FA', borderRadius: 8, padding: 3, marginBottom: 24 }}>
              {(['login', 'signup'] as const).map(m => (
                <button key={m} onClick={() => { setMode(m); setError('') }}
                  style={{ flex: 1, padding: '7px', border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
                    fontFamily: 'inherit', cursor: 'pointer',
                    background: mode === m ? T.white : 'transparent',
                    color: mode === m ? T.navy : T.muted,
                    boxShadow: mode === m ? '0 1px 3px rgba(0,0,0,0.08)' : 'none' }}>
                  {m === 'login' ? 'Sign in' : 'Create account'}
                </button>
              ))}
            </div>

            {/* Google */}
            <button onClick={handleGoogle}
              style={{ width: '100%', padding: '10px 16px', border: `1.5px solid ${T.border}`, borderRadius: 8,
                background: T.white, fontSize: 14, fontWeight: 600, fontFamily: 'inherit',
                cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                color: T.text, marginBottom: 16 }}>
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </button>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: T.border }}/>
              <span style={{ fontSize: 12, color: T.muted }}>or</span>
              <div style={{ flex: 1, height: 1, background: T.border }}/>
            </div>

            {mode === 'signup' && (
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, fontWeight: 600, color: T.muted }}>Full Name</label>
                <input style={inputS} placeholder="Ravi Kumar" value={name} onChange={e => setName(e.target.value)}/>
              </div>
            )}

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: T.muted }}>Work Email</label>
              <input style={inputS} type="email" placeholder="you@company.com" value={email}
                onChange={e => setEmail(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleEmail()}/>
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: T.muted }}>Password</label>
              <input style={inputS} type="password" placeholder="••••••••" value={password}
                onChange={e => setPassword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleEmail()}/>
            </div>

            {error && (
              <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, padding: '8px 12px',
                fontSize: 13, color: T.red, marginBottom: 16 }}>
                {error}
              </div>
            )}

            <button onClick={handleEmail} disabled={loading || !email || !password}
              style={{ width: '100%', padding: '11px', background: loading ? T.muted : T.navy, color: '#fff',
                border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700, fontFamily: 'inherit',
                cursor: loading ? 'not-allowed' : 'pointer' }}>
              {loading ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create free account'}
            </button>

            {mode === 'signup' && (
              <div style={{ fontSize: 11, color: T.muted, textAlign: 'center', marginTop: 14, lineHeight: 1.5 }}>
                Free plan includes 3 projects. No credit card required.
              </div>
            )}
          </div>

          {/* Free tier features */}
          <div style={{ marginTop: 24, background: T.white, borderRadius: 10, border: `1px solid ${T.border}`, padding: '18px 20px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: T.muted, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 12 }}>Free plan includes</div>
            {[
              ['3 projects', 'Full LCOS, DCF, IRR, Bankability analysis'],
              ['All modules', 'Sensitivity, Bid Optimiser, Scenario analysis'],
              ['India benchmarks', 'SECI tariffs, VGF, PFC/REC/SBI norms'],
            ].map(([title, desc]) => (
              <div key={title} style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
                <span style={{ color: T.green, fontWeight: 700, flexShrink: 0 }}>✓</span>
                <div>
                  <span style={{ fontSize: 13, fontWeight: 600, color: T.text }}>{title}</span>
                  <span style={{ fontSize: 12, color: T.muted }}> — {desc}</span>
                </div>
              </div>
            ))}
            <div style={{ borderTop: `1px solid ${T.border}`, marginTop: 12, paddingTop: 12, fontSize: 12, color: T.muted }}>
              PDF export and unlimited projects from <strong style={{ color: T.navy }}>₹4,999/month</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Plan Badge ───────────────────────────────────────────────────
export function PlanBadge({ plan }: { plan: Plan }) {
  const cfg = {
    free:  { label: 'Free',       bg: '#F0F4FA', color: T.muted },
    pro:   { label: 'Pro',        bg: '#DBEAFE', color: T.blue  },
    team:  { label: 'Team',       bg: '#D1FAE5', color: T.green },
  }[plan]
  return (
    <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 20,
      background: cfg.bg, color: cfg.color, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
      {cfg.label}
    </span>
  )
}

// ─── Project Limit Banner ─────────────────────────────────────────
export function ProjectLimitBanner() {
  const { plan, projectCount } = useAuth()
  if (plan !== 'free') return null
  const remaining = Math.max(0, FREE_PROJECT_LIMIT - projectCount)

  return (
    <div style={{ background: remaining === 0 ? '#FEF2F2' : T.light,
      border: `1px solid ${remaining === 0 ? '#FECACA' : T.border}`,
      borderRadius: 8, padding: '10px 14px', marginBottom: 12,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
      <div style={{ fontSize: 13, color: remaining === 0 ? T.red : T.text }}>
        {remaining === 0
          ? 'You\'ve reached the 3-project free limit.'
          : `Free plan: ${remaining} project${remaining !== 1 ? 's' : ''} remaining.`}
      </div>
      <a href="mailto:hello@bessanalytica.com?subject=Upgrade to Pro"
        style={{ fontSize: 12, fontWeight: 700, color: T.white, background: T.navy,
          padding: '5px 14px', borderRadius: 6, textDecoration: 'none', whiteSpace: 'nowrap' }}>
        Upgrade to Pro
      </a>
    </div>
  )
}

// ─── PDF Gate ─────────────────────────────────────────────────────
export function PDFGate({ onClose }: { onClose: () => void }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 999,
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: T.white, borderRadius: 14, padding: '36px 32px', maxWidth: 420, width: '100%' }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: T.navy, marginBottom: 8 }}>PDF Export is a Pro feature</div>
        <div style={{ fontSize: 14, color: T.muted, lineHeight: 1.6, marginBottom: 24 }}>
          Upgrade to Pro to export professional PDF reports suitable for lenders, DISCOMs, and client presentations.
        </div>
        <div style={{ background: T.bg, borderRadius: 8, padding: '16px', marginBottom: 24 }}>
          {[
            'Unlimited PDF exports',
            'Unlimited projects',
            'Priority support',
            'Downloadable Excel model',
          ].map(f => (
            <div key={f} style={{ display: 'flex', gap: 8, marginBottom: 8, fontSize: 13 }}>
              <span style={{ color: T.green, fontWeight: 700 }}>✓</span>
              <span>{f}</span>
            </div>
          ))}
          <div style={{ fontSize: 18, fontWeight: 800, color: T.navy, marginTop: 12 }}>
            ₹4,999<span style={{ fontSize: 13, fontWeight: 400, color: T.muted }}>/month</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <a href="mailto:hello@bessanalytica.com?subject=Upgrade to Pro"
            style={{ flex: 1, background: T.navy, color: '#fff', border: 'none', borderRadius: 8,
              padding: '11px', fontSize: 14, fontWeight: 700, textAlign: 'center', textDecoration: 'none',
              display: 'block' }}>
            Contact us to upgrade
          </a>
          <button onClick={onClose}
            style={{ padding: '11px 18px', border: `1.5px solid ${T.border}`, borderRadius: 8,
              fontSize: 14, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
              background: T.white, color: T.muted }}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── User Menu ────────────────────────────────────────────────────
export function UserMenu() {
  const { profile, plan, signOut } = useAuth()
  const [open, setOpen] = useState(false)

  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setOpen(!open)}
        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 10px',
          background: '#F0F4FA', border: `1px solid ${T.border}`, borderRadius: 6,
          cursor: 'pointer', fontFamily: 'inherit' }}>
        <div style={{ width: 24, height: 24, borderRadius: '50%', background: T.navy,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span style={{ color: '#fff', fontSize: 11, fontWeight: 700 }}>
            {(profile?.name || profile?.email || 'U')[0].toUpperCase()}
          </span>
        </div>
        <span style={{ fontSize: 12, fontWeight: 600, color: T.text, maxWidth: 120,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {profile?.name || profile?.email?.split('@')[0] || 'Account'}
        </span>
        <PlanBadge plan={plan}/>
        <span style={{ fontSize: 10, color: T.muted }}>▾</span>
      </button>

      {open && (
        <>
          <div onClick={() => setOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 90 }}/>
          <div style={{ position: 'absolute', right: 0, top: '100%', marginTop: 6, zIndex: 100,
            background: T.white, border: `1px solid ${T.border}`, borderRadius: 10,
            boxShadow: '0 8px 24px rgba(0,0,0,0.10)', padding: 8, minWidth: 200 }}>
            <div style={{ padding: '8px 12px', borderBottom: `1px solid ${T.border}`, marginBottom: 6 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: T.text }}>{profile?.name || 'User'}</div>
              <div style={{ fontSize: 11, color: T.muted }}>{profile?.email}</div>
            </div>
            {plan === 'free' && (
              <a href="mailto:hello@bessanalytica.com?subject=Upgrade to Pro"
                style={{ display: 'block', padding: '8px 12px', fontSize: 13, color: T.blue,
                  fontWeight: 600, textDecoration: 'none', borderRadius: 6 }}>
                ↑ Upgrade to Pro
              </a>
            )}
            <button onClick={signOut}
              style={{ width: '100%', padding: '8px 12px', textAlign: 'left', border: 'none',
                background: 'none', fontSize: 13, color: T.muted, cursor: 'pointer',
                fontFamily: 'inherit', borderRadius: 6 }}>
              Sign out
            </button>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Root Auth Gate ───────────────────────────────────────────────
export function AuthGate({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()

  if (loading) return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 36, height: 36, background: T.navy, borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
          <span style={{ color: '#fff', fontSize: 16, fontWeight: 800 }}>B·</span>
        </div>
        <div style={{ fontSize: 13, color: T.muted }}>Loading BESSAnalytica…</div>
      </div>
    </div>
  )

  if (!user) return <LoginPage />
  return <>{children}</>
}
