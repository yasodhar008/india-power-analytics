import React from 'react'
import ReactDOM from 'react-dom/client'
import { AuthProvider, AuthGate } from './AuthApp'
import App from './App'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AuthProvider>
      <AuthGate>
        <App />
      </AuthGate>
    </AuthProvider>
  </React.StrictMode>
)
